$(document).ready(function () {
    
    // Gọi hàm này khi trang được tải
    updateCartCount();
    tongdonhang();

    function updateCartCount() {
        // Tìm tất cả các hàng sản phẩm trong bảng giỏ hàng
        var giohang = $("#giohangg").find("tr.cart__row"); 
        var slsp = giohang.length; // Số lượng sản phẩm
        
        // Cập nhật số lượng vào #boxcart > span
        var boxcart = $("#boxcart").children("span").eq(0); 
        if (boxcart.length > 0) {
            boxcart.text(slsp); // Hiển thị số lượng
        } else {
            console.error("Không tìm thấy phần tử span trong #boxcart");
        }
    }
     // Hàm xử lý giá tiền
     function parsePrice(price) {
        return parseInt(price.replace(/[^0-9]/g, ''));
    }
    // Lắng nghe sự kiện "Xóa sản phẩm" và cập nhật giỏ hàng
    $(".cart__remove").on("click", function (e) {
        e.preventDefault(); // Ngăn trình duyệt reload trang nếu có
        var tr = $(this).parent().parent();
        var tensp = tr.children("td").eq(0).text();
        tr.remove();
        updateCartCount(); // Cập nhật lại số lượng sản phẩm
        tongdonhang(); // Cập nhật tổng đơn hàng
    });
     // Sự kiện số lượng thay đổi 
    $(".num").change(function (e) {
        e.preventDefault();
        var sl = parseInt(this.value);
        var tr = $(this).closest("tr");
        var dongia = parsePrice(tr.children("td").eq(2).text());
        var tt = dongia * sl;
        tr.children("td").eq(4).text(tt.toLocaleString() + "₫");
        tongdonhang();
    });
    // Tính tổng đơn hàng
     function tongdonhang() {
        var giohang = $("#giohangg").children("tr");
        var tong = 0;

        giohang.each(function () {
            var thanhtien = parsePrice($(this).children("td").eq(4).text());
            tong += thanhtien;
        });

        $("#tongdonhang").find(".cart__subtotal-value").text(tong.toLocaleString() + "₫");
    }
});


